ALTER TABLE `glpi_plugin_tasklists_tasks`
    CHANGE `comment` `content` text collate utf8mb4_unicode_ci;


