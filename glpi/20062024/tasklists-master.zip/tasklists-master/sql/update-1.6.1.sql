ALTER TABLE `glpi_plugin_tasklists_tasks`
    ADD `users_id_requester`       int(11) NOT NULL DEFAULT '0';


