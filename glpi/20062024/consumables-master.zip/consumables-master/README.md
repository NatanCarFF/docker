# consumables
Plugin consumables pour GLPI

Ce plugin est sur Transifex - Aidez-nous à le traduire :
https://www.transifex.com/infotelGLPI/GLPI_consumables/

This plugin is on Transifex - Help us to translate :
https://www.transifex.com/infotelGLPI/GLPI_consumables/

### Français

Ce plugin vous permet de gérer les demandes de consommables pour les utilisateur finaux.
* Système de validation de demande de consommables
* Notifications associées
* Wizard utilisateur basé sur le stock disponible

![](https://github.com/InfotelGLPI/consumables/blob/master/wiki/Menu%20plugin%20consumables.png)


![](https://github.com/InfotelGLPI/consumables/blob/master/wiki/Wizard%20plugin%20consumables.png)
