# timelineticket

Plugin timelineticket pour GLPI

Ce plugin est sur Transifex - Aidez-nous à le traduire :
https://www.transifex.com/tsmr/GLPI_timelineticket/

This plugin is on Transifex - Help us to translate :
https://www.transifex.com/tsmr/GLPI_timelineticket/

Ce plugin vous permet d'ajouter un onglet Chronologie sur les tickets
> * Historisation et statistiques sur les différents statuts du tickets
> * Historisation et statistiques sur les différents techniciens du tickets
> * Historisation et statistiques sur les différents groupes de techniciens du tickets
> * Rapport sur les temps passés sur les tickets clos

This plugin allows you to add a Timeline tab on tickets
> * History and statistics for differents status of the tickets
> * History and statistics for differents technicians of the tickets
> * History and statistics for differents technicians groups of the tickets
> * Report time spent on closed tickets 
