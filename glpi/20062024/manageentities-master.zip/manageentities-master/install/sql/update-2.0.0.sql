ALTER TABLE `glpi_plugin_manageentities_configs` DROP  `linktocontract`;
ALTER TABLE `glpi_plugin_manageentities_contractstates` ADD  `color` VARCHAR(7) default '#F2F2F2';
