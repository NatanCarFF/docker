ALTER TABLE `glpi_plugin_manageentities_configs` ADD  `company_address` TEXT default NULL;
