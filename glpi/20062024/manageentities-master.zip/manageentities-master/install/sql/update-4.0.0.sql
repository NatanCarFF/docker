UPDATE `glpi_plugin_manageentities_configs` SET `documentcategories_id` = '0' WHERE `documentcategories_id` = '-1';
