ALTER TABLE `glpi_plugin_manageentities_cridetails`
   ADD `plugin_manageentities_contractdays_id` int(11) NOT NULL default '0';
