
# FullCalendar Resource Timeline Plugin

Display events and resources on a horizontal time axis

[View the docs &raquo;](https://fullcalendar.io/docs/timeline-view)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar-scheduler)
