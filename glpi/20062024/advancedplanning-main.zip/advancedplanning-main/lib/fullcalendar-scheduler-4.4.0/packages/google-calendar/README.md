
# FullCalendar Google Calendar Plugin

Fetch events from a public Google Calendar feed

[View the docs &raquo;](https://fullcalendar.io/docs/google-calendar)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar)
