<?php
header('Location: ../front/central.php');