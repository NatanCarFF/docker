ALTER TABLE `glpi_plugin_addressing_profiles`
   ADD `use_ping_in_equipment` char(1) collate utf8_unicode_ci default NULL;

