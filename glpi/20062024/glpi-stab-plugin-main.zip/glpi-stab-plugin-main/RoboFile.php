<?php
require_once 'vendor/autoload.php';

class RoboFile extends Glpi\Tools\RoboFile
{

}
