<?php

function plugin_stab_install() {
   return true;
}

function plugin_stab_uninstall() {
   return true;
}
