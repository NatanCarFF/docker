# Task'n'drop
The Task'n'drop plugin for GLPI

## 2.0.0 - 2022-07-28
### Features
- GLPI 10 Compatibility #10340
### Bugfixes
- PHP Warning when selecting all users of a group at Planning view #6955
  - Fix planning colors for groups over 15 users by @cconard96 in #12339

## 1.3.0 - 2022-07-27
### Features
- Added support for change tasks
