ALTER TABLE `glpi_plugin_activity_options` ADD `use_mandaydisplay` tinyint(11) DEFAULT '0';
ALTER TABLE `glpi_plugin_activity_options` ADD `use_integerschedules` tinyint(1) DEFAULT '0';