ALTER TABLE `glpi_plugin_activity_options` ADD `is_cra_default` int(11) NOT NULL DEFAULT '0';
ALTER TABLE `glpi_plugin_activity_holidaytypes` ADD `is_period` tinyint(1) default '0';

