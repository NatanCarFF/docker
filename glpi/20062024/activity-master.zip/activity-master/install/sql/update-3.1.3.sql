ALTER TABLE `glpi_plugin_activity_options` ADD `use_hour_on_cra` tinyint DEFAULT '0';
ALTER TABLE `glpi_plugin_activity_configs` ADD `is_recursive` tinyint DEFAULT '0';