ALTER TABLE `glpi_plugin_activity_holidayperiods` ADD `archived` tinyint (1) NOT NULL DEFAULT 0;

