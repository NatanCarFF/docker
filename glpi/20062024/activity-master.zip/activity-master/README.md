# activity
Plugin activity for GLPI

Information :

En version 9.5 de GLPI, lors de la mise à jour du plugin, les activités seront migrées dans le cœur de GLPI (comme des événements externes). Le plugin sera utilisé pour la gestion de congés, de l'affichage des jours fériés, et du Compte Rendu d'activité.

WIKI : https://github.com/InfotelGLPI/activity/wiki

L'article du blog Infotel :
http://blogglpi.infotel.com/une-creation-infotel-le-plugin-activity/
