ALTER TABLE `glpi_plugin_webhook_configs`
ADD COLUMN `debug` TINYINT NOT NULL default '0';
