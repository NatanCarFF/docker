#Installation
Decompress the archive into the plugins directory, in a directory named "webhook"
