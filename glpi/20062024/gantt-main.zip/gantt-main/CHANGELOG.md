# Change Log

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [1.1.0] - 2024-03-15

### Added

- Added the ability to export gantt view data in JSON format
- Use real dates if they exist over planned dates for tasks and projects

