<?php

$LANG['plugin_costs']['coststech'] = "Costs Tech";
