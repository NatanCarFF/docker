ALTER TABLE `glpi_plugin_resources_configs` ADD `resource_manager` varchar(255) NOT NULL DEFAULT '';
ALTER TABLE `glpi_plugin_resources_configs` ADD `sales_manager` varchar(255) NOT NULL DEFAULT '';