<?php

global $LANG;

$LANG['plugin_resources']['userwithnoresource'] = 'Active users without linked resource';

