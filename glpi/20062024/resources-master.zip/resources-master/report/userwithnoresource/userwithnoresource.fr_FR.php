<?php

global $LANG;

$LANG['plugin_resources']['userwithnoresource'] = 'Utilisateurs actifs sans ressource associee';


