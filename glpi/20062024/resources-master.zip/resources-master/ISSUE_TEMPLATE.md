Dear GLPi user.

BEFORE SUBMITTING YOUR ISSUE, please make sure to read and follow these steps :

* Verify that your question has not already been asked
* Please use the below template.
* Delete this text before submiting your issue.

The Plugin team.

------------
* Version of the plugin : 


* Version of your GLPI : 


* Steps to reproduce (which actions have you made) :


* Expected result :


* Actual result :


* URL of the page :


* Screenshot of the problem (if pertinent) :

