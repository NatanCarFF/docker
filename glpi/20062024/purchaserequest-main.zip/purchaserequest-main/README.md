# purchaserequest
Plugin purchaserequest for GLPI

Plugin extension for Order plugin (https://github.com/pluginsGLPI/order)
