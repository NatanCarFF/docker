# GappEssentials CHANGELOG

## 2.3.0
### Features
- Endpoint get item documents

## 2.2.0
### Features
- Config for request source

## 2.1.2
### Features
- Return visibility of the category
### Bugfixes
- Fix use with non-compound name 

## 2.1.1
### Bugfixes
- Fix include

## 2.1.0
### Features
- Restrict support to GLPI 10.0.3+

## 2.0.1
### Features
- GLPI 10.0.1 Compatibility #10120

## 2.0.0
### Features
- GLPI 10 Compatibility #9316

## 1.3.0
### Features
- Add a warning if Gapp Essentials is installed in the plugins folder #9374
- Migrate essentials functions to newest version #9370

## 1.2.1
### Bugfixes
- Fix: Error 500 on "pluginList" api request #4508 #9355
