Génération de numéros d'inventaire

Cette extension vous permet de générer automatiquement un numéro d'inventaire. La configuration donne la possibilité de définir :

* Les types qui nécessitent cette automatisation
* Les modèles de numéros à générer
* Si les compteurs sont globaux ou spécifiques pour chaque type

Inventory numbers generation

This plugin enables inventory numbers automatic generation. The configuration allows you to define :

* The types for which automatic generation is enabled
* Inventory number templates
* If counters are globals or type specific
